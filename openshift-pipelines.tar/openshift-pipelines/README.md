## openshift-pipelines

No Kubernetes APIs are being provided by this Operator.  


